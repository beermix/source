// SPDX-License-Identifier: GPL-2.0
/* Copyright(c) 2007 - 2020 Intel Corporation. */

#include "igb.h"

